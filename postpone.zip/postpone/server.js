//Initiallising node modules
var express = require("express");
var bodyParser = require("body-parser");
var sql = require("mssql");
var app = express(); 

// Body Parser Middleware
app.use(bodyParser.json()); 

//CORS Middleware
app.use(function (req, res, next) {
    //Enabling CORS 
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
    next();
});

//Setting up server
 var server = app.listen(process.env.PORT || 8080, function () {
    var port = server.address().port;
    console.log("App now running on port", port);
 });

//Initiallising connection string
var dbConfig = {
    user:  “<dbUserName>”,
    password: “<dbPassword>”,
    server: “<dbHost_URL>”,
    database:” <dbName>”
};

//Function to connect to database and execute query
var  executeQuery = function(res, query){             
     sql.connect(dbConfig, function (err) {
         if (err) {   
                     console.log("Error while connecting database :- " + err);
                     res.send(err);
                  }
                  else {
                         // create Request object
                         var request = new sql.Request();
                         // query to the database
                         request.query(query, function (err, res) {
                           if (err) {
                                      console.log("Error while querying database :- " + err);
                                      res.send(err);
                                     }
                                     else {
                                       res.send(res);
                                            }
                               });
                       }
      });           
}

//GET API
app.get("/api/user", function(req , res){
                var query = "select * from [user]";
                executeQuery (res, query);
});

//POST API
 app.post("/api/user", function(req , res){
                var query = "INSERT INTO [user] (Name,Email,Password) VALUES (req.body.Name,req.body.Email,req.body.Password”);
                executeQuery (res, query);
});

//PUT API
 app.put("/api/user/:id", function(req , res){
                var query = "UPDATE [user] SET Name= " + req.body.Name  +  " , Email=  " + req.body.Email + "  WHERE Id= " + req.params.id;
                executeQuery (res, query);
});

// DELETE API
 app.delete("/api/user /:id", function(req , res){
                var query = "DELETE FROM [user] WHERE Id=" + req.params.id;
                executeQuery (res, query);
});
 class User {
  constructor(name) {
   this._name = name;
   this._loggedIn = false;
   this._lastLoggedInAt = null;
  }
  isLoggedIn() {
    return this._loggedIn;
  }
  getLastLoggedInAt() {
    return this._lastLoggedInAt;
  }
  logIn() {
    this._lastLoggedInAt = new Date();
    this._loggedIn = true;
  }
  logOut() {
    this._loggedIn = false
  }
  getName() {
    return this._name;
  }
  setName(name) {
    this._name = name;
  }
  canEdit(comment) {
    if(comment._author._name === this._name) {
      return true;
    }
    return false;
  }
  canDelete(comment) {
    return false;
  }
}

class Moderator extends User {
   constructor(name) {
     super(name);
   }
   canDelete(comment) {
     return true;
   }
}

class Admin extends Moderator {
  constructor(name) {
    super(name)
  }
  canEdit(comment) {
    return true;
  }
}

class Comment {
   constructor(author = null, message, repliedTo = null) {
     this._createdAt = new Date();
     this._message = message;
     this._repliedTo = repliedTo;
     this._author = author;
   }
   getMessage() {
     return this._message;
   }
   setMessage(message) {
     this._message = message;
   }
   getCreatedAt() {
     return this._createdAt;
   }
   getAuthor() {
     return this._author;
   }
   getRepliedTo() {
     return this._repliedTo;
   }
   toString() {
     if(this._repliedTo === null) {
        return this._message + " by " + this._author._name
     }
     return this._message + " by " + this._author._name + " (replied to " + 
          this._repliedTo._author._name + ")"
   }
 }
 const sql = require("msnodesqlv8");
 
const connectionString = "server=.;Database=Master;Trusted_Connection=Yes;Driver={SQL Server Native Client 11.0}";
const query = "SELECT name FROM sys.databases";
 
sql.query(connectionString, query, (err, rows) => {
    console.log(rows);
});
